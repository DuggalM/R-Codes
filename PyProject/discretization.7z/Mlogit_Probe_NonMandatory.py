# -*- coding: utf-8 -*-
"""
Created on Thu Dec  10 18:07:02 2017

@author: MZD
"""

# import packages
import os
import pandas as pd
import numpy as np
from balsa.matrices import read_mdf, to_mdf, to_fortran, read_fortran_square, read_fortran_rectangle
import Mlogit_Probe_EarlyValid as mprobe_valid
import common
import peak_offpeak as PeakOffpeak
from trips_hhold_mixer import TripsHhold


class NonMandatoryFortranOd(object):
    
    """
    
    """
    
    def __init__(self, prng):

        # set random state
        self.prng = prng

        pass

    # TODO add validation of trip purposes by time period as well
    def validation(self):

        """
        This function validates if the files are available in the folder
        """
        _errorMessage = ""

        # Validation checks for files, both the JSON DTYPE and csv
        EarlyValidFiles = mprobe_valid.EarlyValidFiles_MlogitProbe
        fileList = EarlyValidFiles.getBINFileList()

        for file in (fileList):

            check_existence = common.file_existence(mprobe_valid.dirListing_othertrips, file)
            mprobe_valid.logger.info("%s Other trip purposes necessary to run the program found in the directory" % file)

            if not common.file_existence(mprobe_valid.dirListing_othertrips, file):
                mprobe_valid.logger.info("%s Other trip purposes necessary to run the program not found in the directory" % file)
                return False

        return True


    def convert_df(self, ggh, dirlisting, filename, nzones):
        """

        :param ggh:
        :param filename:
        :param nzones:
        :return:
        """

        # read in the fortran dataframe and then subset it for the internal zones
        # in the GGH.
        df = read_fortran_rectangle(os.path.join(dirlisting, filename), n_columns=4000,
                                    tall=False, reindex_rows=False, fill_value=None)
        df1 = pd.DataFrame(df).iloc[:nzones, :nzones]

        # set column and row indices
        df1.rename(columns=ggh['ggh_zone'], inplace=True)
        df1.set_index(ggh['ggh_zone'], inplace=True)

        # Now unstack and rename columns
        df1 = df1.unstack().reset_index()
        df1.columns = ['origin', 'destination', 'trips']

        # dictionary of market segment key and values
        market_seg_def = {
            'nocar_low.bin': 1,
            "nocar_high.bin": 2,
            "insuff_low.bin": 3,
            "insuff_high.bin": 4,
            "suff_low.bin": 5,
            "suff_high.bin": 6,
            "all_segments.bin": 10
        }

        # Remove zero trips and add in market segmentation and peak-offpeak flag
        df1 = df1.loc[df1['trips'] != 0]
        segment = filename.split('_')
        s1 = segment[5] + '_' + segment[6]
        df1['market_seg'] = s1
        df1['mseg'] = df1['market_seg'].map(market_seg_def)
        df1['period'] = segment[1]
        df1.drop('market_seg', axis=1, inplace=True)

        # Also add in the rounded up trips values
        df1['wholetrips'] = round(df1['trips']).astype(int)
        df1 = df1.loc[df1['wholetrips'] > 0]

        return df1

    def sample_destination(self, current_row, all_othertrips):
        """

        :param current_row:
        :param all_othertrips:
        :return:
        """

        # check if input is not a series and make it into one.
        if isinstance(current_row, pd.DataFrame):
            current_row = current_row.T.squeeze()

        # create the key using the purpose and market segment. Then get the dataframe that belongs to the key
        # Now subset the dataframe by origin being evaluated. This is required for accurately sampling
        df_choose_flag = current_row['purpose'] + '_' + str(current_row['segment'])
        t1 = all_othertrips[mprobe_valid.EarlyValidFiles_MlogitProbe.dict_othertrips_names.get(df_choose_flag)]
        zone_loc = current_row['taz_i']  # save current_row origin taz
        t1_loc = t1.loc[t1['origin'] == zone_loc]

        # if the t1_loc df is empty it means that the Dest Choice model did not produce a trip from that origin
        # for the origin, time period, and market segment in question. One needs to pick another zone
        counter = 1

        while len(t1_loc) == 0:

            newzone_loc = zone_loc + counter
            t1_loc = t1.loc[t1['origin'] == newzone_loc]
            counter += 1
            mprobe_valid.logger.info("%s number was used as a candidate zone for sampling" %newzone_loc)

        # sample for a destination
        sampled_dest = t1_loc.sample(n=1, weights=t1['wholetrips'], replace=True, random_state=self.prng)

        mprobe_valid.logger.info("Destination sampled")
        return sampled_dest.iat[0, 1]



    def destination_solver(self, trips_hhold):
        """

        :param all_other:
        :param trips_hhold:
        :return:
        """
        # set empty dictionary
        all_other = {}

        global new_taz_j
        # batch in ggh zone numbers and add in two columns for i and j zones
        ggh = pd.read_csv(os.path.join(mprobe_valid.dirListing_abm, mprobe_valid.EarlyValidFiles_MlogitProbe.GGH_EQUIV))
        ggh['key'] = 0
        # make a copy of the df and create a square matrix
        ggh1 = ggh
        self.ggh2 = pd.merge(ggh1, ggh, how='left', on='key')

        # batch in the binary files into a dictionary
        for filename in mprobe_valid.EarlyValidFiles_MlogitProbe.getBINFileList():

            all_other[filename] = self.convert_df(ggh, mprobe_valid.dirListing_othertrips, filename, 3262)

            # reset column types
            for key, value in mprobe_valid.EarlyValidFiles_MlogitProbe.dict_nonmandatory_dtype.items():
                all_other[filename][key] = all_other[filename][key].astype(value)


        # build row wise destination for the non-mandatory
        for index, current_row in trips_hhold.iterrows():

            if current_row['purpose'] != 'HBE':

                mprobe_valid.logger.info("Start iterating over the rows of the dataframe, sample and attach destination")
                # this first condition is the start of the loop
                if (current_row['taz_i'] > 0) & (current_row['taz_j'] == 0):
                    # get the zone by sampling from the requisite trip purpose, time period and market segment
                    # and assign as the destination
                    new_taz_j = self.sample_destination(current_row, all_other)
                    trips_hhold.set_value(index, 'taz_j', new_taz_j)

                # this is the next condition the destination is known but not the origin
                # the destination from the previous row becomes the origin
                if (current_row['taz_i'] == 0) & (current_row['taz_j'] != 0):

                    trips_hhold.set_value(index, 'taz_i', new_taz_j)

                    # final condition where neither origin or destination is defined
                # in this case the destination from the previous row becomes the origin
                # and a destination is sampled from the requisite trip purpose, time period and market segment
                if (current_row['taz_i'] == 0) & (current_row['taz_j'] == 0):
                    trips_hhold.set_value(index, 'taz_i', new_taz_j)
                    test_current = trips_hhold.loc[[index]]

                    new_taz_j = self.sample_destination(test_current, all_other)
                    trips_hhold.set_value(index, 'taz_j', new_taz_j)

        return trips_hhold


    def run(self, trips_hhold, nonmandatory_purposes):

        # run destination solver
        trips_hhold = self.destination_solver(trips_hhold)

        # now batch out the necessary matrices
        for purpose in nonmandatory_purposes:

            nonmand_only = trips_hhold.loc[(trips_hhold['purpose'] == purpose)]

            # now loop over the peak periods
            for peak in range(0, 2):

                timeperiod_df = nonmand_only.loc[nonmand_only['peak_flag'] == peak]
                timeperiod_df = timeperiod_df.groupby(['taz_i', 'taz_j', 'purpose', 'segment']).size().reset_index(
                    name='freq')

                # now loop over the segments
                for segment in timeperiod_df['segment'].unique():
                    # create filename and then groupby
                    # only keep relevant cols and set a flag
                    # Merge the ggh zones and the trip list and convert to wide format

                    fname = purpose + "_" + str(segment)
                    df_hbw = timeperiod_df.loc[timeperiod_df['segment'] == segment]
                    df_hbw = df_hbw[['taz_i', 'taz_j']]
                    df_hbw['probflag'] = 1

                    # Make square dataframe for Fortran
                    df_hbw1 = pd.merge(self.ggh2, df_hbw, how="left", left_on=['ggh_zone_x', 'ggh_zone_y'],
                                       right_on=['taz_i', 'taz_j'])
                    df_hbw2 = df_hbw1.pivot_table(index='ggh_zone_x', columns='ggh_zone_y', values='probflag',
                                                  fill_value=0)

                    to_fortran(df_hbw2, os.path.join(mprobe_valid.dirListing_abm, fname + ' peak_flag ' + str(peak) + '.bin'),
                               n_columns=4000)

        pass








