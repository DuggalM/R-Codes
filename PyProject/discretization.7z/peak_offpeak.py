# -*- coding: utf-8 -*-
"""
Created on Monday Dec  11 17:07:02 2017

@author: MZD
"""

# import packages
import os
import pandas as pd
import numpy as np
import Mlogit_Probe_EarlyValid as mprobe_valid
import common

class PeakOffpeak(object):

    """


    """

    def __init__(self):

        pass

    def run(self, trips_hhold_df, peak_consistency):
        """
        This function creates a peak flag for every record in the trips_hhold dataframe. This is needed to ensure that
        MLOGIT produces the correct probabilities by time period and O-D pair. If the peak_consistency flag is
        set to 1 then the function ensures consistency in choosing the peak-off peak flag for the outbound and inbound
        trip of the mandatory tours. This option also increases the run times by around 35 minutes as every row needs to
        be evaluated.
        :param trips_hhold_df: the trips_hhold df that needs a peak flag
        :param peak_consistency: if activated to 1 then consistency between the outbound and inbound trips of the
        mandatory tour are maintained.
        :return: trips_hhold df with peak flag
        """

        # The trips_out file contains a peak hour factor column that decides whether a trip is sampled
        # in the peak or off-peak period. In order to discretely select the peak records and vice-versa
        # an uniform random number generator is run and the values are attached to the trips_out file.
        # If the (1-peak_factor) value in the record is greater than that of the random value than
        # the record is in the off-peak and vice-versa.

        np.random.seed(mprobe_valid.seed)
        random = pd.DataFrame(np.random.uniform(size=len(trips_hhold_df)))
        random.columns = ['rnum']

        # attach the random number generator and calculate peak_flag. A value of 1 in this flag
        # means that this is a peak period trip record.
        trips_hhold_df = common.concat_df(trips_hhold_df, random, 1)
        trips_hhold_df['peak_flag'] = np.where(trips_hhold_df['rnum'] <= trips_hhold_df['peak_factor'], 1, 0)
        trips_hhold_df[['peak_flag']] = trips_hhold_df[['peak_flag']].astype('int8')


        mprobe_valid.logger.info("Return the trips and household dataframe combined with each record that has a home end"
                                 "in it tagged as to whether it starts in the peak (1) or off-peak period (0). The rest"
                                 "of the records are populated with a dummy value of 10 as their time period will be "
                                 "determined by the destination choice model of the GGHMV4")

        # GGHMV4 carries out mode choice for the HBW, HBS, and HBU trips at the PA level. This essentially means that
        # the return trip of that tour must also lie in the same peak period that the home based trip was in.

        if peak_consistency == 1:
            mprobe_valid.logger.info("Peak consistency flag set to %s. This will take 25 min at least" % peak_consistency)
            loop = "Close"
            start_peak_flag = None

            # loop over the trips dataframe for the mandatory trip purposes
            for index, current_row in trips_hhold_df.iterrows():
                if ((current_row['activity_i'] == 'home') & (current_row['activity_j'] in ['work', 'school', 'univerity'])):
                    loop = "Start"
                    start_peak_flag = current_row['peak_flag']

                # the first time the loop reaches a record where the activity at the Jth end is home, the peak flag from
                # the starting leg of the mandatory tour is added to the return trip.
                if ((current_row['activity_j'] == 'home')):
                    if (loop == "Start"):
                        trips_hhold_df.set_value(index, 'peak_flag', start_peak_flag)
                        loop = "Close"
                        start_peak_flag = None

            return trips_hhold_df
        mprobe_valid.logger.info("Peak flag populated")
        return trips_hhold_df